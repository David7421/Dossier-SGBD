@DW/CreaDW.sql
@DW/CreateLogTable.sql
@DW/PackageAlimDW.sql

EXIT;
