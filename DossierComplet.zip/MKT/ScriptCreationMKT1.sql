@MKT/CreaMKT.sql
@MKT/CreateLogTable.sql
@MKT/AlimMKT.sql

EXIT;
