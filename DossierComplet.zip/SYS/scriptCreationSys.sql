@SYS/CreateUsers.sql
@SYS/Acl.sql

EXIT;