@CBB/ProcedureEvalFilm.sql
@CBB/PackageRecherche.sql
@CBB/ProcedureRestore.sql
@CBB/TriggerCopieCotesAvis.sql
@CBB/TriggersCopieFilm.sql

EXIT;

