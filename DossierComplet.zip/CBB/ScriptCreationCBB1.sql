@CBB/CreaCBB.sql
@CBB/CreateLogTable.sql

EXIT;