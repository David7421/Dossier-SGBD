@CC/RegisterXsd.sql
@CC/CreateLogTable.sql
@CC/CreateXMLTable.sql

EXIT;

