@CC/ProcedureInsertXml.sql
@CC/ProcedureArchProg.sql
@CC/ProcedureProgFilm.sql
@CC/CreaJobArchProg.sql
@CC/CreaJobProgFilm.sql

EXIT;

