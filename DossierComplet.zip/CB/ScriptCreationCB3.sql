@CB/ProcedureRetourCopie.sql

EXIT;
