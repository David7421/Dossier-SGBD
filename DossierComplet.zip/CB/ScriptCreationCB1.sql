@CB/CreaCB.sql
@CB/CreateLogTable.sql
@CB/CreaExternalTable.sql
@CB/PackageCB.sql

EXIT;
