@CB/TriggerCopieCotesAvis.sql
@CB/TriggersCopieFilm.sql
@CB/ProcedureBackup.sql
@CB/ProcedureEvalFilm.sql
@CB/PackageRecherche.sql
@CB/CreaXMLCommunicationTable.sql
@CB/CreaJobBackup.sql

